340DBHOST='aws-flask-test-1.cswicfifygp4.us-west-1.rds.amazonaws.com'
# should always be the same

340DBUSER='admin'             
# change root if you setup your project to use a different username

340DBPW='Rockeya2523ss!'
# password for said username if any otherwise just leave everything after = blank

340DB='innodb'
# name of your local database name for the project


flaskadmin
AKIARPMIUEKMPK57SWFG
uHM1PXmjDx9gMtF4Qf+AQdplbT5UiLf4cC2lnrb1